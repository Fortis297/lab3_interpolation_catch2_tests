#include "interpolation.h"

double linear_interpolate(double x, double x0, double x1, double y0, double y1) {

    double h = x1 - x0;
    return y0 + (y1 - y0) / h * (x - x0);
}