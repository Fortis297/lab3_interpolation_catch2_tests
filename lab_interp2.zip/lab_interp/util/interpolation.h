// включем заголовочный файл только один раз во время компиляции
#pragma once

double linear_interpolate(double x, double x0, double x1, double y0, double y1);