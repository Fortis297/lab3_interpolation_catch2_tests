# CMake generated Testfile for 
# Source directory: C:/Users/8240659/lab_interp
# Build directory: C:/Users/8240659/lab_interp
# 
# This file includes the relevant testing commands required for 
# testing this directory and lists subdirectories to be tested as well.
add_test(all_tests "C:/Users/8240659/lab_interp/tests.exe")
set_tests_properties(all_tests PROPERTIES  _BACKTRACE_TRIPLES "C:/Users/8240659/lab_interp/CMakeLists.txt;24;add_test;C:/Users/8240659/lab_interp/CMakeLists.txt;0;")
