# CMake generated Testfile for 
# Source directory: C:/Users/8240659/lab_interp/googletest-1.14.0
# Build directory: C:/Users/8240659/lab_interp/googletest-1.14.0
# 
# This file includes the relevant testing commands required for 
# testing this directory and lists subdirectories to be tested as well.
subdirs("googletest")
