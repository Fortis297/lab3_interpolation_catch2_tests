#include <gtest/gtest.h>
#include "interpolation.h"

TEST(InterpolationTest, BasicFormula) {
    // Формула в середине интервала: y = x
    double result = linear_interpolate(2.0, 1.0, 3.0, 1.0, 3.0);
    EXPECT_DOUBLE_EQ(result, 2.0);
}

TEST(InterpolationTest, NodesExact) {
    // Интерполяция обязана проходить через узлы
    EXPECT_DOUBLE_EQ(linear_interpolate(0.0, 0.0, 1.0, 0.0, 10.0), 0.0);
    EXPECT_DOUBLE_EQ(linear_interpolate(1.0, 0.0, 1.0, 0.0, 10.0), 10.0);
}

TEST(InterpolationTest, SinMidpoint) {
    // Проверка в середине интервала для синуса
    double result = linear_interpolate(0.125, 0.0, 0.25, 0.0, 0.2474);
    EXPECT_NEAR(result, 0.1237, 1e-4);
}