#include <iostream>
#include <cmath>
// для настройки формата ввода-вывода чисел (например, кол-во знаков после запятой)
#include <iomanip>
#include "interpolation.h"

int main() {
// std::fixed - чтобы числа не выводились в экспоненциальной форме, 
// а std::setprecision(4) - это 4 знака после запятой
    std::cout << std::fixed << std::setprecision(4);

   
    std::cout << "\n---- Sinus y = sin(x) on [0; 1], 5 nodes ----\n";
// аргумент, точное значение, интерполяция и ошибка
    std::cout << "x\t\tExact\t\tInterp\t\tError\n";

    // Узлы
    const int n = 5;
    double xs[n] = {0.0, 0.25, 0.5, 0.75, 1.0};
    double ys[n];
    for (int i = 0; i < n; i++) {
        ys[i] = std::sin(xs[i]);
    }

    // Проверяем в точках между узлами
    for (double x = 0.0; x <= 1.0; x += 0.125) {
        // Находим, в каком интервале лежит x
        int i = 0;

// ищет отрезок ([xs[i], xs[i+1]]), внутри которого находится 
// текущая точка x. Пока x больше, чем правая граница следующего отрезка, 
// мы сдвигаем индекс i вправо
        while (i < n - 1 && x > xs[i + 1]) {
            i++;
        }

// точное значение для синуса х
        double exact = std::sin(x);

// вызываем функцию интерполяции из файда
        double approx = linear_interpolate(x, xs[i], xs[i + 1], ys[i], ys[i + 1]);

// считаем ошибку
        double error = std::fabs(exact - approx);

// вывод таблицы
        std::cout << x << "\t\t" << exact << "\t\t" << approx << "\t\t" << error << "\n";
    }

    return 0;
}