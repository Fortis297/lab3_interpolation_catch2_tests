#include <catch_amalgamated.hpp>
#include "interpolation.h"


// [interp] — это тег, чтобы в консоли можно было запустить не все тесты сразу, 
// а только этот (нам же еще нужен гугл тест...)


TEST_CASE("Linear interpolation basic", "[interp]") {
    // Проверяем простой случай: y = x 
    REQUIRE(linear_interpolate(2.0, 1.0, 3.0, 1.0, 3.0) == 2.0);

    // Проверяем, что в узлах значение совпадает с заданным
    REQUIRE(linear_interpolate(0.0, 0.0, 1.0, 0.0, 10.0) == 0.0);
    REQUIRE(linear_interpolate(1.0, 0.0, 1.0, 0.0, 10.0) == 10.0);
}

TEST_CASE("Linear interpolation sin", "[interp][trig]") {
    // узлы для синуса
    double x0 = 0.0, x1 = 0.25;
    double y0 = 0.0, y1 = 0.2474; // это для sin(0.25)
    double x_mid = 0.125;
    double result = linear_interpolate(x_mid, x0, x1, y0, y1);
    REQUIRE(result == 0.1237);
}